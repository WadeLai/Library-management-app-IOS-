//
//  ViewBookViewController.swift
//  Library of Alexandria
//
//  Created by Wade on 16/3/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import UIKit

class ViewBookViewController: UIViewController {


    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var bookInfo: UILabel!
    @IBAction func viewBookSegemented(_ sender: Any) {
        switch segmentedControl.selectedSegmentIndex
        {
        //the first section of segemented control is to display basic book info
        case 0:
            bookInfo.text = "Title: \(String(describing: receivedBook!.title!)) \nAuthor: \(String(describing: receivedBook!.author!)) \nPublisher: \(String(describing: receivedBook!.publisher!)) \nGenre: \(String(describing: receivedBook!.genre!)) \nEdition: \(String(describing: receivedBook!.edition!)) \nYear of Publication: \(receivedBook!.publicationYear) \nISBN: \(receivedBook!.isbn)"
        //the second section of segemented control is to display book description as it contains a lot more texts
        case 1:
            bookInfo.text = receivedBook?.bookDescription
        default:
            break
        }
    }
    
    //this variable is to hold the passed book object from book list controller
    var receivedBook:Book?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.view.backgroundColor = .white
        //change the titles of segemented controls
        segmentedControl.setTitle("Book Information", forSegmentAt: 0)
        segmentedControl.setTitle("Book Description", forSegmentAt: 1)

        //configure the details of the book to be displayed
        bookImage.image = UIImage(named: (receivedBook?.bookImage)!)
        bookInfo.lineBreakMode = .byWordWrapping
        bookInfo.numberOfLines = 0
        bookInfo.text = "Title: \(String(describing: receivedBook!.title!)) \nAuthor: \(String(describing: receivedBook!.author!)) \nPublisher: \(String(describing: receivedBook!.publisher!)) \nGenre: \(String(describing: receivedBook!.genre!)) \nEdition: \(String(describing: receivedBook!.edition!)) \nYear of Publication: \(receivedBook!.publicationYear) \nISBN: \(receivedBook!.isbn)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
