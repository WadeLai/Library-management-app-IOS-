//
//  BookListTableViewCell.swift
//  Library of Alexandria
//
//  Created by Wade on 16/3/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import UIKit

class BookListTableViewCell: UITableViewCell {
    @IBOutlet weak var bookNameLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var genreLabel: UILabel!
    @IBOutlet weak var backView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        backgroundColor = UIColor.init(red: 232/255, green: 236/255, blue: 242/255, alpha: 1.0)
        
        //customize tableView cell
        self.backView.layer.borderWidth = 0.2
        self.backView.layer.cornerRadius = 15
        self.backView.layer.masksToBounds = true
        
        self.layer.shadowOpacity = 0.18
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.layer.shadowRadius = 2
        self.layer.shadowColor = UIColor.gray.withAlphaComponent(0.5).cgColor
        self.layer.masksToBounds = false
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
