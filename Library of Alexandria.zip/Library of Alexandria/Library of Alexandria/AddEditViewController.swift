//
//  AddEditViewController.swift
//  Library of Alexandria
//
//  Created by Wade on 13/3/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import UIKit

class AddEditViewController: UIViewController {
    
    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var ISBNText: UITextField!
    @IBOutlet weak var authorText: UITextField!
    @IBOutlet weak var publisherText: UITextField!
    @IBOutlet weak var yearOfPublicationText: UITextField!
    @IBOutlet weak var editionText: UITextField!
    @IBOutlet weak var genreText: UITextField!
    @IBOutlet weak var descriptionText: UITextField!
    
    //this variable is used to received book object when users wish to edit book from the book list screen
    var bookToEdit:Book?
    
    @IBAction func addBookButton(_ sender: Any) {
        
        //validate input. Ensure all fields are filled. Also, ISBN and year of publication can only contain integer. ISBN can be 10 integer while year of publicaiton can be 4 integer
        if titleText.text != "" && authorText.text! != "" && descriptionText.text! != "" && genreText.text! != "" && editionText.text! != "" && publisherText.text! != "" && yearOfPublicationText.text! != "" && ISBNText.text != "" && ISBNText.text?.count == 10 && yearOfPublicationText.text?.count == 4, let _ = Int(yearOfPublicationText.text!), let _ = Int(ISBNText.text!){
            
            let title = titleText.text!
            let author = authorText.text!
            let publisher = publisherText.text!
            let ISBN = Int64(ISBNText.text!)
            let year = Int16(yearOfPublicationText.text!)
            let edition = editionText.text!
            let genre = genreText.text!
            let description = descriptionText.text!
            
            //display the entered information to user and check if they still want to proceed with the presented book info
            let confirmAlert = UIAlertController(title: "Check the book details", message: "Title: \(title) \n Author: \(author) \n publisher: \(publisher) \n ISBN: \(ISBNText.text!) \n Year: \(yearOfPublicationText.text!) \n Edition: \(edition) \n Genre: \(genre) \n Description: \(description)", preferredStyle: UIAlertControllerStyle.alert)
            
            //if users click confirm. then we can use the entered info to update or add a book
            confirmAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { (action: UIAlertAction!) in
                //if the book info is to be upadted to the exisitng entry in core data
                if self.bookToEdit != nil{
                    //call updateData method to perform update
                    DataHandler.updateData(title: title, isbn: ISBN!, author: author, publisher: publisher, edition: edition, publicationYear: year!, genre: genre, bookDescription: description)
                }
                else{
                    //if users wish to add a new book
                    DataHandler.saveData(title: title, isbn: (ISBN)!, author: author, publisher: publisher, edition: edition, publicationYear: (year)!, genre: genre, bookDescription: description)
                }
                
                //clear text fields
                self.clearTextFields()
                
                //inform users that the action has been sucessfully completed
                let addConfirmAlert = UIAlertController(title: "Confirmation", message: "The book has been sucessfully added/updated to the book list", preferredStyle:
                    UIAlertControllerStyle.alert)

                addConfirmAlert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: { (action: UIAlertAction!) in
                    //go back to main screen
                    self.navigationController?.popToRootViewController(animated: true)
                }))

                self.present(addConfirmAlert, animated: true, completion: nil)
            }))
            
            //if users clicks cancel, nothing happens, they can keep editing text fields
            confirmAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

            //this is to make sure only one viewcontroller is presented at once
            if self.presentedViewController == nil {
                self.present(confirmAlert, animated: true, completion: nil)
            }
            else {
                self.dismiss(animated: false, completion: nil)
                self.present(confirmAlert, animated: true, completion: nil)
            }
        }
        
        //when users dont enter valid data in all the text fields
        else{
            let alertController = UIAlertController(title: "Alert", message: "Please ensure you enter valid inputs", preferredStyle:
                UIAlertControllerStyle.alert)
            
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default, handler:
                nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    //clean input fields
    func clearTextFields(){
        titleText.text = ""
        ISBNText.text = ""
        authorText.text = ""
        publisherText.text = ""
        yearOfPublicationText.text = ""
        editionText.text = ""
        genreText.text = ""
        descriptionText.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //if there is value in bookToEdit. It means users has passed book info from book list and wish to edit the book
        if bookToEdit != nil{
            //put the exisiting book info in the corresponding text fields
            titleText.text = bookToEdit?.title
            //diable user input in title text field
            titleText.isUserInteractionEnabled = false
            publisherText.text = bookToEdit?.publisher
            yearOfPublicationText.text = String(describing: bookToEdit!.publicationYear)
            ISBNText.text = String(describing: bookToEdit!.isbn)
            editionText.text = bookToEdit?.edition
            authorText.text = bookToEdit?.author
            genreText.text = bookToEdit?.genre
            descriptionText.text = bookToEdit?.bookDescription
            //change the title to Edit book
            self.title = "Edit book"
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

