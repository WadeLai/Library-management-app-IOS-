//
//  Book+CoreDataProperties.swift
//  Library of Alexandria
//
//  Created by Wade on 16/4/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//
//

import Foundation
import CoreData


extension Book {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Book> {
        return NSFetchRequest<Book>(entityName: "Book")
    }

    @NSManaged public var author: String?
    @NSManaged public var bookDescription: String?
    @NSManaged public var edition: String?
    @NSManaged public var genre: String?
    @NSManaged public var isbn: Int64
    @NSManaged public var publicationYear: Int16
    @NSManaged public var publisher: String?
    @NSManaged public var title: String?
    @NSManaged public var bookImage: String?

}
