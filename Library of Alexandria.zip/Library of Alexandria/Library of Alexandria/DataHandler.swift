//
//  DataHandler.swift
//  Library of Alexandria
//
//  Created by Wade on 15/4/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DataHandler: NSObject {
    
    //get the NSManagedObjectContext
    private class func getContext() -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        return appDelegate.persistentContainer.viewContext
    }
    
    //Saving new instance of book to core data
    class func saveData(title:String, isbn:Int64, author:String, publisher:String, edition:String, publicationYear:Int16, genre:String, bookDescription:String){
        let context = getContext()
        let book = NSEntityDescription.entity(forEntityName: "Book", in: context)
        let newBook = Book(entity: book!, insertInto: context)
        
        newBook.title = title
        newBook.author = author
        newBook.isbn = isbn
        newBook.publisher = publisher
        newBook.edition = edition
        newBook.publicationYear = publicationYear
        newBook.genre = genre
        newBook.bookDescription = bookDescription
        //newly added book will have a default image
        newBook.bookImage = "DefaultImage.png"
        do{
            try context.save()
            
        }catch{
            fatalError("Failed to add books: \(error)")
        }
    }
    
    //get all the instances of book in core data
    class func fetchData() ->[Book]{
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Book")
        var bookList: [Book] = []
        do {
            bookList = try getContext().fetch(fetchRequest) as! [Book]
            //if there is no book instance in core data
            if bookList.count == 0 {
                initilizeBooks()
                // Load newly added data.
                bookList = try getContext().fetch(fetchRequest) as! [Book]
            }
            return bookList
        }
        catch {
            fatalError("Failed to fetch books: \(error)")
        }
    }
    
    //update existing entry
    class func updateData (title:String, isbn:Int64, author:String, publisher:String, edition:String, publicationYear:Int16, genre:String, bookDescription:String){
        let context = getContext()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Book")
        var bookList: [Book] = []
        do {
            bookList = try getContext().fetch(fetchRequest) as! [Book]
        }
        catch {
            fatalError("Failed to fetch books: \(error)")
        }
        
        //find the book in the core data that has the same book title. Update the information about this book
        for book in bookList{
            if book.title == title{
                book.setValue(author, forKey: "author")
                book.setValue(isbn, forKey: "isbn")
                book.setValue(publisher, forKey: "publisher")
                book.setValue(publicationYear, forKey: "publicationYear")
                book.setValue(genre, forKey: "genre")
                book.setValue(bookDescription, forKey: "bookDescription")
                book.setValue(edition, forKey: "edition")
            }
        }
        
        do{
            try context.save()
            
        }catch{
            fatalError("Failed to add books: \(error)")
        }
    }
    
    //initialize default book data
    class func initilizeBooks(){
        let context = getContext()
        let book = NSEntityDescription.entity(forEntityName: "Book", in: context)
        let defaultBook = Book(entity: book!, insertInto: context)
        
        defaultBook.title = "Harry Potter"
        defaultBook.author = "J. K. Rowling"
        defaultBook.isbn = 1542325312
        defaultBook.publisher = "Monash Publisher"
        defaultBook.edition = "The 2nd edition"
        defaultBook.publicationYear = 2009
        defaultBook.genre = "Fantasy fiction"
        defaultBook.bookDescription = "Harry Potter is a series of fantasy novels written by British author J. K. Rowling. The novels chronicle the life of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry."
        defaultBook.bookImage = "harryPotter1.jpg"
        
        let defaultBook2 = Book(entity: book!, insertInto: context)
        defaultBook2.title = "End of Watch"
        defaultBook2.author = "Stephen King"
        defaultBook2.isbn = 4233543235
        defaultBook2.publisher = "Imaginary publisher"
        defaultBook2.edition = "The 3rd edition"
        defaultBook2.publicationYear = 2001
        defaultBook2.genre = "Thrillers"
        defaultBook2.bookDescription = "For nearly six years, in Room 217 of the Lakes Region Traumatic Brain Injury Clinic, Brady Hartsfield has been in a persistent vegetative state. A complete recovery seems unlikely for the insane perpetrator of the “Mercedes Massacre,” in which eight people were killed and many more maimed for life. "
        defaultBook2.bookImage = "EndOfWatch.jpeg"
        
        let defaultBook3 = Book(entity: book!, insertInto: context)
        defaultBook3.title = "Pieces of Light"
        defaultBook3.author = "Charles Fernyhough"
        defaultBook3.isbn = 1039483921
        defaultBook3.publisher = "Non-exisistent publisher"
        defaultBook3.edition = "The 5th edition"
        defaultBook3.publicationYear = 2015
        defaultBook3.genre = "Memory"
        defaultBook3.bookDescription = "Memory is an essential part of who we are. But what are memories, and how are they created? A new consensus is emerging among cognitive scientists: rather than possessing a particular memory from our past, like a snapshot, we construct it anew each time we are called upon to remember. "
        defaultBook3.bookImage = "PieachOfLight.jpeg"
        
        let defaultBook4 = Book(entity: book!, insertInto: context)
        defaultBook4.title = "The Alchemist"
        defaultBook4.author = "Paulo Coelho"
        defaultBook4.isbn = 1339423921
        defaultBook4.publisher = "Non-exisistent publisher"
        defaultBook4.edition = "The 6th edition"
        defaultBook4.publicationYear = 2001
        defaultBook4.genre = "Fantasy"
        defaultBook4.bookDescription = "The Alchemist (Portuguese: O Alquimista) is a novel by Brazilian author Paulo Coelho which was first published in 1988. Originally written in Portuguese, it became an international bestseller translated into some 70 languages as of 2016.[1][2] An allegorical novel,"
        defaultBook4.bookImage = "the_alchemist.jpg"
        
        let defaultBook5 = Book(entity: book!, insertInto: context)
        defaultBook5.title = "Think and Grow Rich"
        defaultBook5.author = "Napoleon Hill"
        defaultBook5.isbn = 4323452222
        defaultBook5.publisher = "Non-exisistent publisher"
        defaultBook5.edition = "The 2nd edition"
        defaultBook5.publicationYear = 1999
        defaultBook5.genre = "Non-fiction"
        defaultBook5.bookDescription = "Think and Grow Rich was written in 1937 by Napoleon Hill, promoted as a personal development and self-improvement book. Hill writes that he was inspired by a suggestion from business magnate and later-philanthropist Andrew Carnegie."
        defaultBook5.bookImage = "think_and_grow_rich.jpg"
        
        let defaultBook6 = Book(entity: book!, insertInto: context)
        defaultBook6.title = "The Da Vinci Code"
        defaultBook6.author = "Dan Brown"
        defaultBook6.isbn = 1322423921
        defaultBook6.publisher = "whatever publisher"
        defaultBook6.edition = "The 5th edition"
        defaultBook6.publicationYear = 2003
        defaultBook6.genre = "Mystery"
        defaultBook6.bookDescription = "The title of the novel refers to the finding of the first murder victim in the Grand Gallery of the Louvre, naked and posed similar to Leonardo da Vinci's famous drawing, the Vitruvian Man, with mathematic message written beside his body and a pentagram drawn on his chest in his own blood."
        defaultBook6.bookImage = "the_da_vinci_code.jpg"
        
        do{
            try context.save()
            
        }catch{
            fatalError("Failed to initialize books: \(error)")
        }
    }
}




