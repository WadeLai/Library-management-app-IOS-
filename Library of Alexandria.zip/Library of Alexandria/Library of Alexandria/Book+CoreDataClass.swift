//
//  Book+CoreDataClass.swift
//  Library of Alexandria
//
//  Created by Wade on 16/4/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//
//

import Foundation
import CoreData


public class Book: NSManagedObject {

}
