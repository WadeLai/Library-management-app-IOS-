//
//  MainScreenViewController.swift
//  Library of Alexandria
//
//  Created by Wade on 16/3/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import UIKit

class MainScreenViewController: UIViewController {

    @IBOutlet weak var bookListImageView: UIImageView!
    @IBOutlet weak var addImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //intitialize defualt books in core data
        _ = DataHandler.fetchData()
        
        //configure addBook and bookList images
        addImageView.image = UIImage(named: "addButton.jpg")
        bookListImageView.image = UIImage(named: "bookList.png")
        
        //add gesture recognizer to the images above
        let addBookGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addBookTapped(tapGestureRecognizer:)))
        let bookListGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(bookListTapped(tapGestureRecognizer:)))
        addImageView.isUserInteractionEnabled = true
        addImageView.addGestureRecognizer(addBookGestureRecognizer)
        bookListImageView.isUserInteractionEnabled = true
        bookListImageView.addGestureRecognizer(bookListGestureRecognizer)
    }
    
    //get to add book view controller after addBook image is tapped
    @objc func addBookTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        performSegue(withIdentifier: "AddBook", sender: self)
    }
    
    //get to book list view controller after booList image is tapped
    @objc func bookListTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        performSegue(withIdentifier: "BookList", sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindSegue (_ sender: UIStoryboardSegue){
        print("unwinding")
    }
}
