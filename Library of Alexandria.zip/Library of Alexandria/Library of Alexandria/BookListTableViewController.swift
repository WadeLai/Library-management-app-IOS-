//
//  BookListTableViewController.swift
//  Library of Alexandria
//
//  Created by Wade on 16/3/18.
//  Copyright © 2018 WadeLai. All rights reserved.
//

import UIKit

class BookListTableViewController: UITableViewController, UISearchResultsUpdating{
    
    //implementing UISearchResultUpdating protocol
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text?.lowercased(),searchText.count > 0 {
            filterdTitleArray = titleArray.filter({(title: String) -> Bool in
                return title.lowercased().contains(searchText)
            })
        }
        else {
            filterdTitleArray = titleArray
        }
        tableView.reloadData();
    }
    

    //declare variables
    private var SECTION_BOOK = 0
    private var SECTION_COUNT = 1
    
    var bookList: [Book] = []
    var titleArray:[String] = []
    var filterdTitleArray:[String] = []
    var valueToPass:Book?
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //get the exisiting book instances in core data
        bookList = DataHandler.fetchData()
        
        //store the information of book to be displayed on table in corresponding arrays
        for book in bookList{
            titleArray.append(book.title!)
        }
        
        //initialize fiterdTitleArray
        filterdTitleArray = titleArray
        
        //remove the lines between tableview cells
        self.tableView.separatorStyle = .none
        
        let searchController = UISearchController(searchResultsController: nil);
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Book"
        searchController.hidesNavigationBarDuringPresentation = false
        navigationItem.searchController = searchController
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (section == SECTION_COUNT)
        {
            return 1
        }
        return filterdTitleArray.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cellResuseIdentifier = "bookNameAuthor"
        
        //section is book count
        if indexPath.section == SECTION_COUNT {
            cellResuseIdentifier = "totalBook"
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellResuseIdentifier, for: indexPath)
        
        // Configure the cell...
        //section is book
        if indexPath.section == SECTION_BOOK{

            let bookCell = cell as! BookListTableViewCell
            bookCell.bookNameLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 18)
            bookCell.bookNameLabel.text = (String(describing: filterdTitleArray[indexPath.row]))
            
            //change the value of labels in tableview cell according to the book allocated to that cell
            for book in bookList{
                if (book.title == filterdTitleArray[indexPath.row]){
                    bookCell.authorLabel.text = "Author: \(String(describing: book.author!))"
                    bookCell.genreLabel.text = "Genre: \(String(describing: book.genre!))"
                    bookCell.bookImage.image = UIImage(named: book.bookImage!)
                }
            }
        }
        else{
            cell.textLabel?.text = "\(filterdTitleArray.count) Books"
        }
        return cell
    }
    
    //when users click on the row. go to the view book controller to display the details of the book
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == SECTION_BOOK{
            //go to ViewBookController to display the details of the selected book
            performSegue(withIdentifier: "SelectBook", sender: self)
        }
    }
 
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //pass the information about the clicked book to ViewBookViewController for it to display the details of the book
        if segue.identifier == "SelectBook"{
            let viewBookController :ViewBookViewController = segue.destination as! ViewBookViewController
            let indexPath = self.tableView.indexPathForSelectedRow
            
            //find which book is selected by user
            for book in bookList{
                if (book.title! == filterdTitleArray[(indexPath?.row)!]){
                    valueToPass = book
                }
            }
            //pass the selected book to ViewBookController
            viewBookController.receivedBook = valueToPass
        }
        //if users wish to edit the seleted book
        else if segue.identifier == "EditBook"{
            let viewBookController :AddEditViewController = segue.destination as! AddEditViewController
            
            //pass the selected book to AddEditViewController
            viewBookController.bookToEdit = valueToPass
        }
    }
    
    //allow swiping left on tableview cell to perfrom edit.
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
            //delete funciton is not necessary in this assignment according to FAQ so i didnt implement the delete function
        }
        
        let share = UITableViewRowAction(style: .normal, title: "Edit") { (action, indexPath) in
            // share item at indexPath
            for book in self.bookList{
                if (book.title! == self.filterdTitleArray[indexPath.row]){
                    self.valueToPass = book
                }
            }
           self.editBook()
        }
        
        share.backgroundColor = UIColor.blue
        
        return [delete, share]
    }
    
    //GO TO AddEditViewController to modifty the selected book
    func editBook (){
        performSegue(withIdentifier: "EditBook", sender: self)
    }
}
